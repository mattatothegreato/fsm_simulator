function Machine(){
	this.states = new List();
	this.startState = null;
	this.alphabet = new AlphabetList();

	this.addState = function(s){
		if(s != null){
			this.states.add(s);
			if(this.startState == null) this.startState = s;
		}
	}

	this.getState = function(id){
		for(var x = 0; x < this.states.size(); x++){
			if(this.states.get(x).id === id) return this.states.get(x);
		}
		return null;
	}

	this.removeState = function(id){
		for(var x = 0; x < this.states.size(); x++){
			if(this.states.get(x).id === id) this.states.remove(x);
		}
		if(this.startState != null && this.startState.id === id) this.startState = null;
	}

	this.removeTransition = function(id){
		var s1 = id.substring(0, id.indexOf("->"));

		this.getState(s1).removeTransition(id);
	}

	this.setStart = function(id){
		var result = this.getState(id);
		if(result != null) this.startState = result;
	}

	this.validate = function(){
		var valid = this.startState != null;
		for(var x = 0; x < this.states.size(); x++){
			valid = valid && this.states.get(x).validate(this.alphabet);
		}
		return valid;
	}

	this.testString = function(s){
		if(this.validate()){
			var current = this.startState;
			for(var x = 0; (x < s.length && current != null); x++){
				var c = s.charAt(x);
				current = current.translate(c);
			}
			return current != null && current.isEnd();
		}
		else{
			alert("Invalid machine.");
			alert(this.toString());
			return false;
		}
	}

	this.toString = function(){
		var result = "Alphabet: " + this.alphabet.toString() + "\n";
		for(var x = 0; x < this.states.size(); x++){
			result += "\n" + x + ": ";
			if(this.startState == this.states.get(x)) result += "---(start)---";
			result += this.states.get(x).toString();
		}
		return result;
	}
}

function State(id, e){
	this.id = id;
	this.end = e;
	this.transitions = new List();

	this.toggleAccept = function(){
		this.end = !this.end;
	}

	this.addTransition = function(t){
		this.removeTransition(t.id);
		this.transitions.add(t);
	}

	this.removeTransition = function(id){
		for(var x = 0; x < this.transitions.size(); x++){
			if(this.transitions.get(x).id === id) this.transitions.remove(x);
		}
	}

	this.translate = function(c){
		var result = null;

		var x = 0;
		while(result == null && x < this.transitions.size()){
			result = this.transitions.get(x).go(c);
			x++;
		}
		return result;
	}

	this.validate = function(alphabet){
		var valid = true;
		for(var x = 0; x < this.transitions.size(); x++){
			valid = valid && this.transitions.get(x).validate(alphabet);
		}
		return valid;
	}

	this.isEnd = function(){
		return this.end;
	}

	this.toString = function(){
		var result = "\n    " + this.id + ": " + this.end;
		for(var x = 0; x < this.transitions.size(); x++){
			result += this.transitions.get(x).toString() + "\n";
		}
		return result;
	}
}

function Transition(id, n, cs){
	this.id = id;
	this.next = n;
	this.characters = new AlphabetList();

	for(var x = 0; x < cs.length; x++){
		this.characters.add(cs[x]);
	}

	this.go = function(c){
		if(this.characters.has(c)) return this.next;
		return null;
	}

	this.getNext = function(){
		return this.next;
	}

	this.validate = function(alphabet){
		var valid = true;
		for(var x = 0; x < this.characters.size(); x++){
			valid = valid && alphabet.has(this.characters.get(x));
		}
		return valid;
	}

	this.toString = function(){
		var result = "\n        (" + this.id + "): " + this.characters.toString();
		return result;
	}
}