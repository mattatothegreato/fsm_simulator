function List(){
	this.length = 0;
	this.array = [];

	this.add = function(element){
		this.array.push(element);
		this.length++;
	}

	this.get = function(index){
		if(index < 0 || index >= this.length) return null;
		return this.array[index];
	}

	this.size = function(){
		return this.length;
	}

	this.remove = function(index){
		if(index < 0 || index >= this.length) return null;
		if(index == this.length){
			this.length--;
			return this.array.pop();
		}

		var element = this.array[index];
		for(var i = index; i < this.length; i++){
			this.array[i-1] = this.array[i];
		}
		this.array.pop();
		this.length--;
		return element;
	}
}

function AlphabetList(){
	this.list = new List();

	this.add = function(c){
		if(!this.has(c)) this.list.add(c);
	}

	this.has = function(c){
		for(var x = 0; x < this.list.size(); x++){
			if(this.list.get(x) == c) return true;
		}
		return false;
	}

	this.size = function(){
		return this.list.size();
	}

	this.get = function(index){
		return this.list.get(index);
	}

	this.toString = function(){
		var result = "";
		for(var x = 0; x < this.list.size() - 1; x++){
			result += this.list.get(x) + ", ";
		}
		if(this.list.size() > 0) result += this.list.get(this.list.size() - 1);
		return "[" + result + "]";
	}
}