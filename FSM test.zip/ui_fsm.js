var machine = new Machine();

var transitionList = new List();
var startTransition;

function setup(){
	var start = document.createElement("div");
	start.setAttribute("id", "start");
	start.setAttribute("class", "start");
	document.getElementById("mainCanvas").appendChild(start);
}

var counter = 0;
function addState(){
	var canvas = document.getElementById("mainCanvas");

	var needsStart = machine.startState == null;

	var stateId = "s" + counter;
	var newElement = document.createElement("div");
	machine.addState(new State(stateId, false));

	newElement.setAttribute("id", stateId);
	newElement.setAttribute("class", "draggable");
	newElement.innerHTML = "<br>" + counter;

	canvas.appendChild(newElement);
	setupState(stateId);
	counter++;

	if(needsStart) setStart(stateId);
}

function setupState(id){
	$("#" + id).draggable({ 
		containment: "#mainCanvas", 
		scroll: true,
		start: function(){
			//hide transitions
		},
		drag: function(){ 
		},
		stop: function(){
			update(id);
		},
	});
	$("#" + id).dblclick(function(){
		toggleAccept(id);
	});	
}

function renameState(id, name){
	document.getElementById(id).innerHTML = name;
}

function removeState(id){
	machine.removeState(id);

	var x = 0;
	while(x < transitionList.size()){
		if(transitionList.get(x).hasState(id)){
			transitionList.get(x).remove();
			transitionList.remove(x);
		}
		else x++;
	}
	document.getElementById("mainCanvas").removeChild(document.getElementById(id));
}

function toggleAccept(id){
	var state = machine.getState(id);
	if(state != null){
		state.toggleAccept();
		$("#" + id).toggleClass("accept");
	}
	else alert(machine.toString());
}

function toggleHighlight(id){
	$("#" + id).toggleClass("highlight");
}

function setStart(id){
	machine.setStart(id);


	if(machine.startState != null){
		alert("visually change start");
		updateStart();
	}
}

function startVisibility(show){
	if(show){
		$("#start").css("visibility", "visible");
	}
	else{
		$("#start").css("visibility", "hidden");
	}
}

function addTransition(id1, id2, characters){
	var s1 = machine.getState(id1);
	var s2 = machine.getState(id2);

	var cs = [];
	for(var x = 0; x < characters.length; x++){
		if(characters.charAt(x) != ' ') cs.push(characters.charAt(x));
	}

	s1.addTransition(new Transition(id1 + "->" + id2, s2, cs));

	var id = id1 + "->" + id2;
	removeTransitionVISUAL(id);
	var ui_transition = new UI_Transition(id1, id2, characters);
	transitionList.add(ui_transition);
}

function removeTransition(id1, id2){
	var id = id1 + "->" + id2;
	machine.removeTransition(id);

	removeTransitionVISUAL(id);
}

function removeTransitionVISUAL(id){
	for(var x = 0; x < transitionList.size(); x++){
		if(transitionList.get(x).id === id){
			transitionList.get(x).remove();
			transitionList.remove(x);
		}
	}
}

function update(id){
	for(var x = 0; x < transitionList.size(); x++){
		if(transitionList.get(x).hasState(id)) transitionList.get(x).repaint();
	}
	updateStart();
}

function updateStart(){
	if(machine.startState == null){
		startVisibility(false);
	}
	else{
		var start_arrow = $("#start");
		var state = $("#" + machine.startState.id);

		var x1 = state.position().left;
		var y1 = state.position().top;
		var height = state.height();
		var w = start_arrow.width();
		var h = start_arrow.height();



		start_arrow.css("left", x1 - w);
		start_arrow.css("top", y1 + height/2 - h/2);

		startVisibility(true);
	}
}

//functions for testing the string
function addToAlphabet(str){
	for(var x = 0; x < str.length; x++){
		var c = str.charAt(x);
		machine.alphabet.add(c);
	}
}

var lineThickness = 1;
function UI_Transition(id1, id2, characters){
	//variables
	this.id = id1 + "->" + id2; //id for the transition
	this.id1 = id1; //start state
	this.id2 = id2;	//end state
	this.label = new TransitionLabel(this.id + "_label", characters); //label to be centered on the transition (STILL HAVE TO UPDATE IN REPAINT)

	this.color = "#ffffff"; //default color, set in repaint (which is used to reset highlighted color)
	//each transition type has a certain color to differentiate it from other transitions

	//the three segments that make up the transition
	this.sourceSegment = new Segment(this.id + "_source");
	this.middleSegment = new Segment(this.id + "_middle");
	this.finishSegment = new Segment(this.id + "_finish");

	this.hasState = function(id){
		return this.id1 === id || this.id2 === id;
	}

	this.repaint = function(){
		//changes the segments
		var s1 = $("#" + this.id1);
		var s2 = $("#" + this.id2);;

		var x1 = s1.position().left;
		var x2 = s2.position().left;
		var y1 = s1.position().top;
		var y2 = s2.position().top;

		var w = s1.width(); 	//should be same for s1 and s2
		var h = s1.height();	//should be same for s1 and s2

		var dx = Math.abs(x1 - x2);
		var dy = Math.abs(y1 - y2);

		if(this.id1 === this.id2){ //draw a loop
			var random = Math.random() * 5; //roll random number to determine where to draw the loop
			var width = w * .6;
			var height = w * .6;
			if(random < 1){ //draw on top
				this.sourceSegment.set(x1 + w * .8, y1 - height, lineThickness, height);
				this.middleSegment.set(x1 + w * .2, y1 - height, width, lineThickness);
				this.label.set(x1 + w * .2, y1 - height);
				this.finishSegment.set(x1 + w * .2, y1 - height, lineThickness, height);

				this.color = "#ffbf00";
			}
			else if(random < 2){ //left
				this.sourceSegment.set(x1 - width, y1 + h * .2, width, lineThickness);
				this.middleSegment.set(x1 - width, y1 + h * .2, lineThickness, height);
				this.label.set(x1 - width, y1 + h * .2);
				this.finishSegment.set(x1 - width, y1 + h * .8, width, lineThickness);

				this.color = "#00ff3f";
			}
			else if(random < 3){ //bottom
				this.sourceSegment.set(x1 + w * .2, y1 + h, lineThickness, height);
				this.middleSegment.set(x1 + w * .2, y1 + h + height, width, lineThickness);
				this.label.set(x1 + w * .8, y1 + h + height);
				this.finishSegment.set(x1 + w * .8, y1 + h, lineThickness, height);

				this.color = "#003fff";
			}
			else{ //right
				this.sourceSegment.set(x1 + w, y1 + h * .8, width, lineThickness);
				this.middleSegment.set(x1 + w + width, y1 + h * .2, lineThickness, height);
				this.label.set(x1 + w + width, y1 + h * .2);
				this.finishSegment.set(x1 + w, y1 + h * .2, width, lineThickness);

				this.color = "#ff00bf";
			}
		}
		else if(dx > dy){ //use left and right
			var width = dx - w;
			var height = dy;
			if(x1 > x2){
				this.sourceSegment.set(x1 - width * .4, y1 + h * .2, width * .4, lineThickness);
				if(y1 < y2){
					this.middleSegment.set(x1 - width * .4, y1 + h * .2, lineThickness, height);
					this.label.set(x1 - width * .4, y1 + h * .2 + height/2);
				}
				else{
					this.middleSegment.set(x1 - width * .4, y2 + h * .2, lineThickness, height);
					this.label.set(x1 - width * .4, y2 + h * .2 + height/2);
				}
				this.finishSegment.set(x2 + w, y2 + h * .2, width * .6, lineThickness);

				this.color = "#ff0000";
			}
			else{ //x1 <= x2
				this.sourceSegment.set(x1 + w, y1 + h * .8, width * .4, lineThickness);
				if(y1 < y2){
					this.middleSegment.set(x1 + w + width * .4, y1 + h * .8, lineThickness, height);
					this.label.set(x1 + w + width * .4, y1 + h * .8 + height/2);
				}
				else{
					this.middleSegment.set(x1 + w + width * .4, y2 + h * .8, lineThickness, height);
					this.label.set(x1 + w + width * .4, y2 + h * .8 + height/2);
				}
				this.finishSegment.set(x1 + w + width * .4, y2 + h * .8, width * .6, lineThickness);

				this.color = "#7fff00";
			}
		}
		else{ //use top and bottom
			var width = dx;
			var height = dy - h;
			if(y1 < y2){
				this.sourceSegment.set(x1 + w * .2, y1 + h, lineThickness, height * .4);
				if(x1 < x2){
					this.middleSegment.set(x1 + w * .2, y1 + h + height * .4, width, lineThickness);
					this.label.set(x1 + w * .2 + width/2, y1 + h + height * .4);
				}
				else{
					this.middleSegment.set(x2 + w * .2, y1 + h + height * .4, width, lineThickness);
					this.label.set(x2 + w * .2 + width/2, y1 + h + height * .4);
				}
				this.finishSegment.set(x2 + w * .2, y1 + h + height * .4, lineThickness, height * .6);

				this.color = "#00ffff";
			}
			else{
				this.sourceSegment.set(x1 + w * .8, y1 - height * .4, lineThickness, height * .4);
				if(x1 < x2){
					this.middleSegment.set(x1 + w * .8, y1 - height * .4, width, lineThickness);
					this.label.set(x1 + w * .8 + width/2, y1 - height * .4);
				}
				else{
					this.middleSegment.set(x2 + w * .8, y1 - height * .4, width, lineThickness);
					this.label.set(x2 + w * .8 + width/2, y1 - height * .4);
				}
				this.finishSegment.set(x2 + w * .8, y2 + h, lineThickness, height * .6);

				this.color = "#7f00ff";
			}
		}

		this.resetColor();
	}

	this.changeColor = function(c){
		this.sourceSegment.changeColor(c);
		this.middleSegment.changeColor(c);
		this.finishSegment.changeColor(c);
		this.label.changeColor(c);
	}

	this.resetColor = function(){
		this.changeColor(this.color);
	}

	this.remove = function(){
		alert(this.id);
		this.sourceSegment.remove();
		this.middleSegment.remove();
		this.finishSegment.remove();
		this.label.remove();
	}



	this.repaint();
}

function Segment(id){
	this.id = id;

	this.htmlElement = document.createElement("div");
	this.htmlElement.setAttribute("id", this.id);
	this.htmlElement.setAttribute("class", "segment");
	document.getElementById("mainCanvas").appendChild(this.htmlElement);

	this.set = function(x, y, w, h){
		this.htmlElement.style.left = x + "px";
		this.htmlElement.style.top = y + "px";
		this.htmlElement.style.width = w + "px";
		this.htmlElement.style.height = h + "px";
	}

	this.changeColor = function(c){
		this.htmlElement.style.backgroundColor = c;
	}

	this.remove = function(){
		this.htmlElement.parentNode.removeChild(this.htmlElement);
	}
}

function TransitionLabel(id, text){ 
	this.id = id; 
	this.text = text;
	//setup tooltip and click functionality

	this.htmlElement = document.createElement("div");
	this.htmlElement.setAttribute("id", this.id);
	this.htmlElement.setAttribute("class", "transition-label");
	this.htmlElement.innerHTML = text;
	document.getElementById("mainCanvas").appendChild(this.htmlElement);

	this.changeColor = function(c){
		this.htmlElement.style.borderColor = c;
		this.htmlElement.style.color = c;
	}

	this.set = function(x, y){
		this.htmlElement.style.left = x;
		this.htmlElement.style.top = y;
	}

	this.remove = function(){
		this.htmlElement.parentNode.removeChild(this.htmlElement);
	}
}